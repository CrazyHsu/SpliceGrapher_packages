
Labels = __import__('PyML.containers.labels', fromlist=['']).Labels
VectorDataSet = __import__('PyML.containers.vectorDatasets', fromlist=['']).VectorDataSet
SparseDataSet = __import__('PyML.containers.vectorDatasets', fromlist=['']).SparseDataSet
SequenceData = __import__('PyML.containers.sequenceData', fromlist=['']).SequenceData
#PositionalKmerData = __import__('PyML.containers.sequenceData', fromlist=['']).PositionalKmerData
Aggregate = __import__('PyML.containers.aggregate', fromlist=['']).Aggregate
KernelData = __import__('PyML.containers.kernelData', fromlist=['']).KernelData
PairDataSet = __import__('PyML.containers.pairData', fromlist=['']).PairDataSet

import ker

